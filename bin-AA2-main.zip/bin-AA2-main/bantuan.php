<div class="page-header">
    <h1>Tentang Sistem</h1>
</div>
<h4>
    Sistem Pakar Deteksi Penyakit Ibu Hamil adalah aplikasi kesehatan berbasis AI yang mendukung wanita selama masa kehamilan mereka - mulai dari awal masa kehamilan hingga menjelang proses persalinan.
</h4>
<div class="text-center">
    <img class="mb-5" style="width: 700px" src="assets/images/main.png" alt="Orang Ramai">
</div>
<h4>
    <p><b>Memungkinkan Anda untuk mengontrol kesehatan Anda</b></p>
    <p>Kami mendukung setiap orang yang mengalami masalah sepanjang masa kehamilannya dengan prediksi berdasarkan gejala yang dipersonalisasi, asisten kesehatan virtual, wawasan tentang kesehatan umum, dan kehamilan.</p>
</h4>
<h4>
    <p><b>Memberikan informasi kesehatan ahli untuk semua</b></p>
    <p>Ahli, informasi kesehatan berbasis bukti harus tanpa syarat dan tersedia untuk semua orang. Kami bekerja sama dengan tim besar dokter medis dan organisasi kesehatan wanita untuk menyediakan informasi kesehatan yang dapat Anda percayai.</p>
</h4>
<h4>
    <p><b>Menjaga informasi pribadi tetap pribadi dan aman</b></p>
    <p>Privasi di era digital adalah yang paling penting. Flo menyediakan platform yang aman untuk semua orang.</p>
</h4>